package com.example.snapbill

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
