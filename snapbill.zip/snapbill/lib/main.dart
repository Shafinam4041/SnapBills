import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:snapbill/screens/splash_page.dart'; // Import SplashPage
import 'package:snapbill/screens/login.dart'; // Import LoginPage
import 'package:snapbill/screens/signin_mannual.dart'; // Import the SignUpPage
import 'package:snapbill/screens/dashboard_page.dart'; // Import the DashboardPage
import 'package:firebase_auth/firebase_auth.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Initialize Firebase
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SnapBills',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      initialRoute: '/splash', // Start with SplashPage
      routes: {
        '/splash': (context) =>  SplashPage(), // SplashPage as the entry point
        '/login': (context) => LoginPage(), // LoginPage
        '/signin': (context) => const SignUpPage(), // SignUpPage
        '/dashboard': (context) => const DashboardPage(), // DashboardPage
      },
    );
  }
}
