import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class TrendsPage extends StatefulWidget {
  @override
  _TrendsPageState createState() => _TrendsPageState();
}

class _TrendsPageState extends State<TrendsPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  late User? _user;
  late DateTime _selectedMonth;

  @override
  void initState() {
    super.initState();
    _user = _auth.currentUser;
    _selectedMonth = DateTime.now(); // Set default to current month
  }

  // Fetch the daily expenses for the selected month
  Future<List<FlSpot>> _fetchMonthlyExpenses() async {
    if (_user == null) return [];

    DateTime firstDayOfMonth = DateTime(
        _selectedMonth.year, _selectedMonth.month, 1);
    DateTime lastDayOfMonth = DateTime(
        _selectedMonth.year, _selectedMonth.month + 1, 0);

    // Fetch expenses from Firestore for the selected month
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(_user!.uid)
        .collection('expenses')
        .where('expenseDate',
        isGreaterThanOrEqualTo: Timestamp.fromDate(firstDayOfMonth))
        .where(
        'expenseDate', isLessThanOrEqualTo: Timestamp.fromDate(lastDayOfMonth))
        .get();

    // Initialize a map to hold daily expenses
    Map<int, double> dailyExpenses = {};

    // Aggregate expenses by day
    for (var doc in querySnapshot.docs) {
      final data = doc.data() as Map<String, dynamic>;
      DateTime expenseDate = (data['expenseDate'] as Timestamp).toDate();
      double amount = (data['amount'] as num)
          .toDouble(); // Ensure it's treated as a double

      int day = expenseDate.day;
      if (dailyExpenses.containsKey(day)) {
        dailyExpenses[day] = dailyExpenses[day]! + amount;
      } else {
        dailyExpenses[day] = amount;
      }
    }

    // Prepare the data for the bar chart
    List<FlSpot> spots = [];
    for (int i = 1; i <= lastDayOfMonth.day; i++) {
      double totalExpense = dailyExpenses[i] ?? 0.0;

      // Ensure both i and totalExpense are double values
      spots.add(FlSpot(i.toDouble(), totalExpense)); // Both are double
    }

    return spots;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Monthly Expense Trends'),
        backgroundColor: Colors.blue, // Set AppBar color to blue
        foregroundColor: Colors.white, // Set text/icons to white for better contrast
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: FutureBuilder<List<FlSpot>>(
          future: _fetchMonthlyExpenses(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text('No expenses for this month.'));
            } else {
              return LineChart(
                LineChartData(
                  gridData: FlGridData(
                    show: true,
                    drawHorizontalLine: true, // Show horizontal grid lines
                    drawVerticalLine: true, // Show vertical grid lines
                  ),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                            showTitles: true, reservedSize: 40)), // Increased space
                    bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                            showTitles: true, reservedSize: 40)), // Increased space
                    topTitles: AxisTitles(
                        sideTitles: SideTitles(showTitles: false)),
                    rightTitles: AxisTitles(
                        sideTitles: SideTitles(showTitles: false)),
                  ),
                  borderData: FlBorderData(show: true),
                  minY: 0,
                  maxY: 20000,
                  lineBarsData: [
                    LineChartBarData(
                      spots: snapshot.data!,
                      isCurved: true,
                      color: Colors.blue,
                      dotData: FlDotData(show: false),
                      belowBarData: BarAreaData(
                          show: true, color: Colors.blue.withOpacity(0.3)),
                    ),
                  ],
                ),
              );
            }
          },
        ),
      ),
    );
  }

}
