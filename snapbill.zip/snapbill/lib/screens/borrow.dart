import 'package:flutter/material.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:snapbill/screens/debiterslist.dart';
import 'debt_history_page.dart';
import 'addgroup.dart';
import 'viewgroups.dart';

class ManageDebtsPage extends StatefulWidget {
  @override
  _ManageDebtsPageState createState() => _ManageDebtsPageState();
}

class _ManageDebtsPageState extends State<ManageDebtsPage> {
  List<Contact> _contacts = [];
  List<Contact> _filteredContacts = [];
  final FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _checkPermissionsAndFetchContacts();
    _searchController.addListener(_filterContacts);
  }

  Future<void> _checkPermissionsAndFetchContacts() async {
    final status = await Permission.contacts.status;
    if (status.isGranted) {
      await _fetchContacts();
    } else if (status.isDenied) {
      if (await Permission.contacts.request().isGranted) {
        await _fetchContacts();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Contacts permission is required to use this feature.")),
        );
      }
    } else if (status.isPermanentlyDenied) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text("Contacts permission is permanently denied. Please enable it in settings."),
          action: SnackBarAction(
            label: "Settings",
            onPressed: () {
              openAppSettings();
            },
          ),
        ),
      );
    }
  }

  Future<void> _fetchContacts() async {
    try {
      final Iterable<Contact> contacts = await ContactsService.getContacts();
      setState(() {
        _contacts = contacts.toList();
        _filteredContacts = _contacts;
      });
    } catch (e) {
      print("Error fetching contacts: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to fetch contacts: $e")),
      );
    }
  }

  void _filterContacts() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      _filteredContacts = _contacts
          .where((contact) =>
      contact.displayName != null &&
          contact.displayName!.toLowerCase().contains(query))
          .toList();
    });
  }

  Widget _buildContactList() {
    return ListView.builder(
      itemCount: _filteredContacts.length,
      itemBuilder: (context, index) {
        final contact = _filteredContacts[index];
        final String displayName = contact.displayName ?? "Unknown";
        final String email = contact.emails!.isNotEmpty ? contact.emails!.first.value! : "No Email";

        return Card(
          elevation: 1,
          margin: EdgeInsets.symmetric(vertical: 5, horizontal: 10),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: CircleAvatar(
              radius: 24,
              backgroundColor: Colors.grey[300],
              child: contact.avatar != null && contact.avatar!.isNotEmpty
                  ? ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: Image.memory(contact.avatar!),
              )
                  : Icon(Icons.person, size: 24, color: Colors.white),
            ),
            title: Text(
              displayName,
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
            ),
            subtitle: Text(email, style: TextStyle(color: Colors.grey[600])),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => DebtHistoryPage(contactName: displayName)),
              );
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Text("Manage Debts"),
        elevation: 0,
        backgroundColor: Colors.blue, // Set the AppBar color to blue
        foregroundColor: Colors.white, // Set text/icons to white for better contrast
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: "Search Contacts",
                  prefixIcon: Icon(Icons.search, color: Colors.black54),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ),
          Expanded(
            child: _contacts.isEmpty ? Center(child: CircularProgressIndicator()) : _buildContactList(),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  /// **Custom Bottom Navigation Bar with Blue Gradient**
  Widget _buildBottomNavigationBar() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade700, Colors.blue.shade900], // Gradient from light to dark blue
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(25),
          topRight: Radius.circular(25),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3), // Shadow for elevation
            spreadRadius: 5,
            blurRadius: 10,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(25),
          topRight: Radius.circular(25),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: Colors.white, // White color for selected item
          unselectedItemColor: Colors.white70, // Light white for unselected items
          selectedFontSize: 14,
          unselectedFontSize: 12,
          type: BottomNavigationBarType.fixed,
          onTap: (index) {
            if (index == 1) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ViewGroupsPage()));
            } else if (index == 2) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => DebtorsListPage()));
            } else if (index == 3) {
              Navigator.push(context, MaterialPageRoute(builder: (context) => AddGroupPage()));
            }
          },
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.home, size: 28), label: "Home"),
            BottomNavigationBarItem(icon: Icon(Icons.group, size: 28), label: "Groups"),
            BottomNavigationBarItem(icon: Icon(Icons.money, size: 28), label: "Debts"),
            BottomNavigationBarItem(icon: Icon(Icons.add, size: 28), label: "Create Group"),
          ],
        ),
      ),
    );
  }
}
