import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';

class ExpensePage extends StatefulWidget {
  @override
  _ExpensePageState createState() => _ExpensePageState();
}

class _ExpensePageState extends State<ExpensePage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _frequencyController = TextEditingController();
  DateTime? _selectedRenewalDate;
  DateTime? _selectedExpenseDate;

  File? _billImage;
  final ImagePicker _picker = ImagePicker();
  bool _isUploading = false;

  final List<String> _categories = [
    'Utilities', 'Food', 'Transport', 'Entertainment', 'Subscriptions', 'Shopping', 'Other',
  ];

  final List<String> _currencies = [
    'INR', 'USD', 'EUR', 'GBP', 'AUD', 'JPY',
  ];

  String? _selectedCategory;
  String? _selectedCurrency = 'INR';

  Future<void> _pickImage() async {
    final pickedImage = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      setState(() {
        _billImage = File(pickedImage.path);
      });
    }
  }

  Future<void> _selectDate(BuildContext context, bool isExpenseDate) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isExpenseDate ? (_selectedExpenseDate ?? DateTime.now()) : (_selectedRenewalDate ?? DateTime.now()),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        if (isExpenseDate) {
          _selectedExpenseDate = picked;
        } else {
          _selectedRenewalDate = picked;
        }
      });
    }
  }

  Future<void> _uploadExpense() async {
    if (!_formKey.currentState!.validate()) return;

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('User not logged in')),
      );
      return;
    }

    setState(() {
      _isUploading = true;
    });

    try {
      String? imageUrl;
      if (_billImage != null) {
        final storageRef = FirebaseStorage.instance
            .ref()
            .child('bills/${user.uid}/${DateTime.now().millisecondsSinceEpoch}.jpg');
        final uploadTask = storageRef.putFile(_billImage!);
        final snapshot = await uploadTask;
        imageUrl = await snapshot.ref.getDownloadURL();
      }

      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('expenses')
          .add({
        'title': _titleController.text.trim(),
        'amount': double.parse(_amountController.text.trim()),
        'description': _descriptionController.text.trim(),
        'category': _selectedCategory,
        'currency': _selectedCurrency,
        'billUrl': imageUrl,
        'expenseDate': _selectedExpenseDate ?? DateTime.now(),
        'createdAt': FieldValue.serverTimestamp(),
        if (_selectedCategory == 'Subscriptions') ...{
          'renewalDate': _selectedRenewalDate?.toIso8601String(),
          'frequency': _frequencyController.text.trim(),
        },
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Expense added successfully')),
      );

      _titleController.clear();
      _amountController.clear();
      _descriptionController.clear();
      setState(() {
        _billImage = null;
        _selectedCategory = null;
        _selectedRenewalDate = null;
        _selectedExpenseDate = null;
        _selectedCurrency = 'INR';
        _frequencyController.clear();
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error adding expense: $e')),
      );
    } finally {
      setState(() {
        _isUploading = false;
      });
    }
  }

  Widget _buildTextField({
    required String label,
    required TextEditingController controller,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        contentPadding: const EdgeInsets.symmetric(vertical: 15, horizontal: 12),
      ),
      validator: validator,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Expense', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blue,
        elevation: 5,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Card(
            elevation: 5,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    _buildTextField(label: 'Title', controller: _titleController, validator: (value) => value!.isEmpty ? 'Title is required' : null),
                    const SizedBox(height: 16),
                    _buildTextField(
                      label: 'Amount',
                      controller: _amountController,
                      keyboardType: TextInputType.number,
                      validator: (value) => value!.isEmpty ? 'Amount is required' : (double.tryParse(value) == null ? 'Enter a valid number' : null),
                    ),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                        labelText: 'Currency',
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      value: _selectedCurrency,
                      items: _currencies.map((currency) {
                        return DropdownMenuItem<String>(value: currency, child: Text(currency));
                      }).toList(),
                      onChanged: (value) => setState(() => _selectedCurrency = value),
                    ),
                    const SizedBox(height: 16),
                    _buildTextField(label: 'Description', controller: _descriptionController, maxLines: 3),
                    const SizedBox(height: 16),
                    DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                        labelText: 'Category',
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      value: _selectedCategory,
                      items: _categories.map((category) {
                        return DropdownMenuItem<String>(value: category, child: Text(category));
                      }).toList(),
                      onChanged: (value) => setState(() => _selectedCategory = value),
                    ),
                    const SizedBox(height: 16),
                    if (_selectedCategory == 'Subscriptions') ...[
                      _buildTextField(label: 'Frequency (e.g. Monthly)', controller: _frequencyController),
                      const SizedBox(height: 16),
                    ],
                    ElevatedButton.icon(
                      icon: const Icon(Icons.upload_file),
                      label: const Text('Upload Bill Image'),
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                      onPressed: _pickImage,
                    ),
                    if (_billImage != null) Image.file(_billImage!, height: 200, fit: BoxFit.cover),
                    const SizedBox(height: 16),
                    _isUploading
                        ? const Center(child: CircularProgressIndicator())
                        : ElevatedButton(
                      onPressed: _uploadExpense,
                      child: const Text('Add Expense'),
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
