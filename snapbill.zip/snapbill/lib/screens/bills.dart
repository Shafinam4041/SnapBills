import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

void main() {
  runApp(MaterialApp(
    theme: ThemeData(
      primarySwatch: Colors.blue,
      scaffoldBackgroundColor: Colors.grey[200],
    ),
    home: BillScannerApp(),
  ));
}

class BillScannerApp extends StatefulWidget {
  @override
  _BillScannerAppState createState() => _BillScannerAppState();
}

class _BillScannerAppState extends State<BillScannerApp> {
  final TextRecognizer _textRecognizer = TextRecognizer();
  bool isLoading = false;
  String _formattedText = "";
  String _products = "";
  File? _billImage;
  final ImagePicker _picker = ImagePicker();
  bool _isUploading = false;

  TextEditingController _dateController = TextEditingController();
  String _selectedCategory = "Food";
  TextEditingController _titleController = TextEditingController();

  Future<void> uploadBill() async {
    // Show dialog to select whether to pick from gallery or camera
    final pickedImage = await showDialog<XFile>(
      context: context,
      builder: (context) =>
          AlertDialog(
            title: Text('Select Image Source'),
            actions: [
              TextButton(
                onPressed: () async {
                  final image = await _picker.pickImage(
                      source: ImageSource.gallery);
                  Navigator.of(context).pop(image);
                },
                child: Text('Gallery'),
              ),
              TextButton(
                onPressed: () async {
                  final image = await _picker.pickImage(
                      source: ImageSource.camera);
                  Navigator.of(context).pop(image);
                },
                child: Text('Camera'),
              ),
            ],
          ),
    );

    if (pickedImage != null) {
      setState(() {
        isLoading = true;
        _billImage = File(pickedImage.path);
      });

      try {
        final inputImage = InputImage.fromFilePath(pickedImage.path);
        await processText(inputImage);
      } catch (e) {
        setState(() {
          _formattedText = "Error processing image: $e";
        });
      } finally {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> processText(InputImage inputImage) async {
    try {
      final recognizedText = await _textRecognizer.processImage(inputImage);
      String formattedText = recognizedText.text;
      setState(() {
        _formattedText = formattedText;
      });

      await extractProductsAndPrices(formattedText);
    } catch (e) {
      print('Error: $e');
    }
  }

  Future<void> extractProductsAndPrices(String text) async {
    final apiKey = "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"; // Replace with API key

    final url = Uri.parse('https://api.openai.com/v1/chat/completions');
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $apiKey',
    };

    final body = json.encode({
      'model': 'gpt-4',
      'messages': [
        {
          'role': 'system',
          'content': 'Extract product names and prices from the bill text.'
        },
        {'role': 'user', 'content': text}
      ],
      'max_tokens': 1000,
    });

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _products = data['choices'][0]['message']['content'].trim();
        });
      } else {
        setState(() {
          _products = "Error: ${response.statusCode}";
        });
      }
    } catch (e) {
      setState(() {
        _products = "Error: $e";
      });
    }
  }

  Future<void> _uploadExpense() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    setState(() {
      _isUploading = true;
    });

    try {
      String? imageUrl;
      if (_billImage != null) {
        final storageRef = FirebaseStorage.instance
            .ref()
            .child('bills/${user.uid}/${DateTime
            .now()
            .millisecondsSinceEpoch}.jpg');
        final snapshot = await storageRef.putFile(_billImage!);
        imageUrl = await snapshot.ref.getDownloadURL();
      }

      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('expenses')
          .add({
        'amount': 1000,
        'billUrl': imageUrl,
        'category': _selectedCategory,
        'createdAt': FieldValue.serverTimestamp(),
        'description': _products,
        'expenseDate': Timestamp.fromDate(DateTime.parse(_dateController.text)),
        'title': _titleController.text,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Expense added successfully')),
      );

      setState(() {
        _billImage = null;
        _products = "";
        _dateController.clear();
        _titleController.clear();
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error adding expense: $e')),
      );
    } finally {
      setState(() {
        _isUploading = false;
      });
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (pickedDate != null) {
      setState(() {
        _dateController.text = "${pickedDate.toLocal()}".split(' ')[0];
      });
    }
  }

  @override
  void dispose() {
    _textRecognizer.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Bill Scanner"),
        backgroundColor: Colors.blue, // Set the color to blue
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Center(
              child: _billImage == null
                  ? Icon(Icons.receipt, size: 100, color: Colors.grey)
                  : Image.file(_billImage!, height: 150),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(Icons.upload),
              label: Text("Upload Bill"),
              onPressed: uploadBill,
            ),
            const SizedBox(height: 20),
            if (isLoading) Center(child: CircularProgressIndicator()),
            if (_formattedText.isNotEmpty)
              Card(
                elevation: 2,
                margin: EdgeInsets.symmetric(vertical: 10),
                child: Padding(
                  padding: EdgeInsets.all(10),
                  child: Text("Extracted Text:\n$_formattedText"),
                ),
              ),
            Card(
              elevation: 2,
              margin: EdgeInsets.symmetric(vertical: 10),
              child: Padding(
                padding: EdgeInsets.all(10),
                child: Text("Products and Prices:\n${_products.isEmpty
                    ? "No data yet."
                    : _products}"),
              ),
            ),
            TextField(
              controller: _dateController,
              decoration: InputDecoration(
                labelText: "Select Date",
                suffixIcon: Icon(Icons.calendar_today),
              ),
              readOnly: true,
              onTap: () => _selectDate(context),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _selectedCategory,
              onChanged: (newValue) =>
                  setState(() => _selectedCategory = newValue!),
              items: ['Food', 'Transport', 'Shopping', 'Other']
                  .map((value) =>
                  DropdownMenuItem(value: value, child: Text(value)))
                  .toList(),
            ),
            const SizedBox(height: 10),
            TextField(controller: _titleController,
                decoration: InputDecoration(labelText: "Title")),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _uploadExpense,
              child: _isUploading ? CircularProgressIndicator() : Text(
                  "Upload to Firebase"),
            ),
          ],
        ),
      ),
    );
  }
}
