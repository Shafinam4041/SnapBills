import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:table_calendar/table_calendar.dart';
import 'edit_expense_page.dart';

class ViewExpensesPage extends StatefulWidget {
  @override
  _ViewExpensesPageState createState() => _ViewExpensesPageState();
}

class _ViewExpensesPageState extends State<ViewExpensesPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  late User? _user;
  late DateTime _selectedDate;
  CalendarFormat _calendarFormat = CalendarFormat.month;
  late Future<Map<String, dynamic>> _expenseData;

  @override
  void initState() {
    super.initState();
    _user = _auth.currentUser;
    _selectedDate = DateTime.now();
    _initializeNotifications();
    _requestNotificationPermissions();
    _expenseData = _fetchExpenses();
  }

  Future<void> _initializeNotifications() async {
    AwesomeNotifications().initialize(
      null,
      [
        NotificationChannel(
          channelKey: 'subscription_alerts',
          channelName: 'Subscription Alerts',
          channelDescription: 'Alerts for subscriptions nearing renewal dates',
          defaultColor: Colors.deepPurple,
          ledColor: Colors.white,
          importance: NotificationImportance.High,
          channelShowBadge: true,
        ),
      ],
    );
  }

  Future<void> _requestNotificationPermissions() async {
    final isAllowed = await AwesomeNotifications().isNotificationAllowed();
    if (!isAllowed) {
      await AwesomeNotifications().requestPermissionToSendNotifications();
    }
  }

  Future<Map<String, dynamic>> _fetchExpenses({DateTime? startDate, DateTime? endDate}) async {
    if (_user == null) return {'expenses': [], 'totalAmount': 0.0};

    Query query = FirebaseFirestore.instance
        .collection('users')
        .doc(_user!.uid)
        .collection('expenses')
        .orderBy('expenseDate', descending: true);

    if (startDate != null && endDate != null) {
      query = query.where('expenseDate', isGreaterThanOrEqualTo: Timestamp.fromDate(startDate))
          .where('expenseDate', isLessThanOrEqualTo: Timestamp.fromDate(endDate));
    }

    final querySnapshot = await query.get();
    final expenses = querySnapshot.docs.map((doc) {
      final data = doc.data() as Map<String, dynamic>?;

      DateTime expenseDate = data?['expenseDate'] is Timestamp
          ? (data?['expenseDate'] as Timestamp).toDate()
          : DateTime.parse(data?['expenseDate'] ?? DateTime.now().toString());

      return {
        'id': doc.id,
        'title': data?['title'] ?? '',
        'amount': data?['amount'] ?? 0.0,
        'description': data?['description'] ?? '',
        'category': data?['category'] ?? '',
        'billUrl': data?['billUrl'],
        'renewalDate': data?['renewalDate'],
        'expenseDate': expenseDate,
      };
    }).toList();

    double totalAmount = expenses.fold(0.0, (sum, expense) => sum + expense['amount']);
    return {'expenses': expenses, 'totalAmount': totalAmount};
  }

  Widget _buildExpenseList(List<Map<String, dynamic>> expenses) {
    return ListView.builder(
      itemCount: expenses.length,
      itemBuilder: (context, index) {
        final expense = expenses[index];

        return Card(
          elevation: 6,
          margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          child: ListTile(
            contentPadding: const EdgeInsets.all(12),
            leading: expense['billUrl'] != null
                ? ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(expense['billUrl'], width: 50, height: 50, fit: BoxFit.cover),
            )
                : Icon(Icons.receipt_long, color: Colors.blue.shade700, size: 35),
            title: Text(
              expense['title'],
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(expense['description'], style: const TextStyle(color: Colors.grey)),
                const SizedBox(height: 4),
                Text('₹${expense['amount'].toStringAsFixed(2)}',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green.shade700)),
              ],
            ),
            trailing: IconButton(
              icon: const Icon(Icons.edit, color: Colors.blue),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => EditExpensePage(expense: expense)),
                );
              },
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('View Expenses', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blue,
        elevation: 5,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, size: 28),
            onPressed: () {
              setState(() => _expenseData = _fetchExpenses());
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TableCalendar(
                focusedDay: _selectedDate,
                firstDay: DateTime(2020),
                lastDay: DateTime(2100),
                calendarFormat: _calendarFormat,
                onDaySelected: (selectedDay, focusedDay) {
                  setState(() {
                    _selectedDate = selectedDay;
                    _expenseData = _fetchExpenses(
                      startDate: DateTime(selectedDay.year, selectedDay.month, selectedDay.day),
                      endDate: DateTime(selectedDay.year, selectedDay.month, selectedDay.day, 23, 59, 59),
                    );
                  });
                },
                selectedDayPredicate: (day) => isSameDay(_selectedDate, day),
                calendarStyle: CalendarStyle(
                  selectedDecoration: BoxDecoration(
                    color: Colors.blue.shade700,
                    shape: BoxShape.circle,
                  ),
                  todayDecoration: BoxDecoration(
                    color: Colors.blue.shade200,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: FutureBuilder<Map<String, dynamic>>(
                future: _expenseData,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  } else if (!snapshot.hasData || snapshot.data!['expenses'].isEmpty) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.receipt_long, color: Colors.grey.shade400, size: 80),
                          const SizedBox(height: 10),
                          Text(
                            "No expenses found!",
                            style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
                          ),
                        ],
                      ),
                    );
                  } else {
                    return _buildExpenseList(snapshot.data!['expenses']);
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
