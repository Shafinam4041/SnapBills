import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:url_launcher/url_launcher.dart';

class ScanQRCodePage extends StatefulWidget {
  @override
  _ScanQRCodePageState createState() => _ScanQRCodePageState();
}

class _ScanQRCodePageState extends State<ScanQRCodePage> {
  final MobileScannerController cameraController = MobileScannerController();
  String? upiId;
  bool isValidUPI = false;

  // Form fields
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  String _selectedCategory = "Food"; // Default category

  // Function to handle QR Code scan
  void _handleQRCodeScan(String qrCode) {
    if (qrCode.contains('upi://pay?pa=')) {
      final Uri uri = Uri.parse(qrCode);
      final String? extractedUpiId = uri.queryParameters['pa'];

      if (extractedUpiId != null && _isValidUPIId(extractedUpiId)) {
        setState(() {
          upiId = extractedUpiId;
          isValidUPI = true;
        });
      } else {
        _showErrorDialog('Invalid UPI ID');
        setState(() {
          isValidUPI = false;
          upiId = null;
        });
      }
    } else {
      _showErrorDialog('Scanned QR code is not a valid UPI QR');
      setState(() {
        isValidUPI = false;
        upiId = null;
      });
    }
  }

  // Validate UPI ID format
  bool _isValidUPIId(String upiId) {
    final RegExp regex = RegExp(r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$');
    return regex.hasMatch(upiId);
  }

  // Function to save payment details to Firebase Firestore
  Future<void> _saveTransactionToFirestore(String amount, String description) async {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) {
      _showErrorDialog("User not authenticated!");
      return;
    }

    try {
      await FirebaseFirestore.instance.collection('transactions').add({
        'userId': user.uid,
        'upiId': upiId,
        'amount': amount,
        'description': description,
        'category': _selectedCategory,
        'timestamp': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Transaction details saved')),
      );
    } catch (e) {
      print('Error saving transaction: $e');
      _showErrorDialog('Failed to save transaction');
    }
  }

  // Function to make a secure UPI payment
  Future<void> _payWithUPI() async {
    if (upiId == null || !isValidUPI) {
      _showErrorDialog('Invalid UPI ID. Please scan a valid QR code.');
      return;
    }

    final String amount = _amountController.text.trim();
    final String description = _descriptionController.text.trim();

    if (amount.isEmpty || description.isEmpty) {
      _showErrorDialog('Please fill all fields before proceeding.');
      return;
    }

    if (double.tryParse(amount) == null || double.parse(amount) <= 0) {
      _showErrorDialog('Enter a valid payment amount.');
      return;
    }

    // Save transaction details to Firestore before proceeding
    await _saveTransactionToFirestore(amount, description);

    final Uri url = Uri.parse(
      'upi://pay?pa=$upiId&pn=Merchant&mc=0000&tid=123456&tr=987654&tn=$description&am=$amount&cu=INR',
    );

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
      _clearFields();
    } else {
      _showErrorDialog('Unable to launch UPI payment');
    }
  }

  // Function to clear form fields after payment
  void _clearFields() {
    setState(() {
      upiId = null;
      isValidUPI = false;
      _amountController.clear();
      _descriptionController.clear();
      _selectedCategory = "Food";
    });
  }

  // Function to show error messages
  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Error'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan & Pay via UPI'),
        backgroundColor: Colors.blue, // Blue header
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: MobileScanner(
                controller: cameraController,
                onDetect: (BarcodeCapture barcodeCapture) {
                  final String scannedData = barcodeCapture.barcodes.first.rawValue ?? '';
                  _handleQRCodeScan(scannedData);
                },
              ),
            ),
            if (upiId != null) ...[
              const SizedBox(height: 16),
              Text(
                'UPI ID: $upiId',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),

              // Amount Field
              TextField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: "Payment Amount (INR)",
                  prefixIcon: Icon(Icons.currency_rupee),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),

              // Description Field
              TextField(
                controller: _descriptionController,
                decoration: InputDecoration(
                  labelText: "Payment Description",
                  prefixIcon: Icon(Icons.description),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),

              // Category Dropdown
              DropdownButtonFormField<String>(
                value: _selectedCategory,
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedCategory = newValue!;
                  });
                },
                items: ['Food', 'Transport', 'Shopping', 'Other']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                decoration: InputDecoration(
                  labelText: "Category",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.category),
                ),
              ),
              const SizedBox(height: 16),

              // Pay Button
              ElevatedButton.icon(
                onPressed: _payWithUPI,
                icon: const Icon(Icons.payment),
                label: const Text('Pay via UPI'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                  textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    theme: ThemeData(primarySwatch: Colors.blue),
    home: ScanQRCodePage(),
  ));
}
