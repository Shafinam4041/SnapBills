import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:snapbill/screens/login.dart'; // Import the LoginPage

class SplashPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Add a delay and navigate to the LoginPage directly after a few seconds
    Future.delayed(const Duration(seconds: 2), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) =>  LoginPage()),
      );
    });

    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Welcome to SnapBills',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            const CircularProgressIndicator(), // Show a loading spinner
          ],
        ),
      ),
    );
  }
}
