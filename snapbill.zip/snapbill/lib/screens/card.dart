import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Card Details App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.grey[200],
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8.0),
          ),
        ),
      ),
      home: CardDetailsPage(),
    );
  }
}

class CardDetailsPage extends StatefulWidget {
  @override
  _CardDetailsPageState createState() => _CardDetailsPageState();
}

class _CardDetailsPageState extends State<CardDetailsPage> {
  final _formKey = GlobalKey<FormState>();
  final _cardHolderController = TextEditingController();
  final _cardNumberController = TextEditingController();
  final _expiryDateController = TextEditingController();
  final _cvvController = TextEditingController();
  String _cardType = 'Credit';

  Future<void> _saveCardDetails() async {
    if (_formKey.currentState?.validate() ?? false) {
      try {
        final user = FirebaseAuth.instance.currentUser;
        if (user != null) {
          await FirebaseFirestore.instance.collection('cards').add({
            'userId': user.uid,
            'cardHolder': _cardHolderController.text,
            'cardNumber': _cardNumberController.text,
            'expiryDate': _expiryDateController.text,
            'cvv': _cvvController.text,
            'cardType': _cardType,
            'createdAt': FieldValue.serverTimestamp(),
          });

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Card details saved successfully')),
          );

          _cardHolderController.clear();
          _cardNumberController.clear();
          _expiryDateController.clear();
          _cvvController.clear();
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error saving card details')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Credit/Debit Card'),
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              DropdownButtonFormField<String>(
                value: _cardType,
                onChanged: (value) {
                  setState(() {
                    _cardType = value!;
                  });
                },
                items: [
                  DropdownMenuItem(value: 'Credit', child: Text('Credit Card')),
                  DropdownMenuItem(value: 'Debit', child: Text('Debit Card')),
                ],
                decoration: InputDecoration(labelText: 'Card Type'),
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _cardHolderController,
                decoration: InputDecoration(labelText: 'Cardholder Name'),
                validator: (value) =>
                value!.isEmpty ? 'Please enter cardholder name' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _cardNumberController,
                decoration: InputDecoration(labelText: 'Card Number'),
                keyboardType: TextInputType.number,
                validator: (value) =>
                value!.length != 16 ? 'Card number must be 16 digits' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _expiryDateController,
                decoration: InputDecoration(labelText: 'Expiry Date (MM/YY)'),
                keyboardType: TextInputType.datetime,
                validator: (value) =>
                value!.isEmpty ? 'Please enter expiry date' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _cvvController,
                decoration: InputDecoration(labelText: 'CVV'),
                keyboardType: TextInputType.number,
                obscureText: true,
                validator: (value) => value!.length != 3 ? 'CVV must be 3 digits' : null,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveCardDetails,
                child: Text('Save Card Details', style: TextStyle(fontSize: 18)),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ViewSavedCardsPage()),
                  );
                },
                child: Text('View Saved Cards', style: TextStyle(fontSize: 18)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// View Saved Cards Page
class ViewSavedCardsPage extends StatefulWidget {
  @override
  _ViewSavedCardsPageState createState() => _ViewSavedCardsPageState();
}

class _ViewSavedCardsPageState extends State<ViewSavedCardsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Saved Cards'), backgroundColor: Colors.blue),
      body: FutureBuilder<QuerySnapshot>(
        future: FirebaseFirestore.instance
            .collection('cards')
            .where('userId', isEqualTo: FirebaseAuth.instance.currentUser?.uid)
            .get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No saved cards found.'));
          }

          var cardDocs = snapshot.data!.docs;

          return ListView.builder(
            itemCount: cardDocs.length,
            itemBuilder: (context, index) {
              var card = cardDocs[index];
              return Card(
                margin: EdgeInsets.all(12),
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: ListTile(
                  title: Text(
                    card['cardHolder'],
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text('Card Type: ${card['cardType']}'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CardDetailsViewPage(card: card),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// Card Details View Page
class CardDetailsViewPage extends StatelessWidget {
  final QueryDocumentSnapshot card;

  CardDetailsViewPage({required this.card});

  void _copyCardNumberToClipboard(BuildContext context) {
    Clipboard.setData(ClipboardData(text: card['cardNumber']));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Card Number copied to clipboard')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Card Details'), backgroundColor: Colors.blue),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          elevation: 5,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Cardholder: ${card['cardHolder']}',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 10),
                GestureDetector(
                  onTap: () => _copyCardNumberToClipboard(context),
                  child: Text('Card Number: ${card['cardNumber']}',
                      style: TextStyle(fontSize: 16, color: Colors.blue)),
                ),
                SizedBox(height: 10),
                Text('Expiry: ${card['expiryDate']}'),
                SizedBox(height: 10),
                Text('CVV: ${card['cvv']}'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
