import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ProfilePage extends StatefulWidget {
  final User user;

  ProfilePage({required this.user});

  @override
  _ProfilePageState createState() => _ProfilePageState();
}
class _ProfilePageState extends State<ProfilePage> {
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  String _profileImageUrl = '';

  @override
  void initState() {
    super.initState();
    _loadUserProfile();  // Fetch the profile data from Firestore
  }

  // Method to load user profile from Firestore
  Future<void> _loadUserProfile() async {
    final FirebaseAuth _auth = FirebaseAuth.instance;
    final User? currentUser = _auth.currentUser;

    if (currentUser != null) {
      // Fetch user data from Firestore
      final userDocRef = FirebaseFirestore.instance.collection('users').doc(currentUser.uid);
      final userDoc = await userDocRef.get();

      if (userDoc.exists) {
        // Update controllers with the user data from Firestore
        final data = userDoc.data()!;
        _nameController.text = data['displayName'] ?? '';
        _phoneController.text = data['phoneNumber'] ?? '';
        _profileImageUrl = data['photoURL'] ?? currentUser.photoURL ?? '';
      }
      setState(() {}); // Refresh the UI after loading the data
    }
  }

  Future<void> _pickImage() async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        _profileImageUrl = image.path;
      });
    }
  }

  Future<void> _updateProfile() async {
    try {
      final FirebaseAuth _auth = FirebaseAuth.instance;
      final User? currentUser = _auth.currentUser;
      if (currentUser != null) {
        final userDocRef = FirebaseFirestore.instance.collection('users').doc(currentUser.uid);
        await userDocRef.set({
          'displayName': _nameController.text,
          'phoneNumber': _phoneController.text,
          'photoURL': _profileImageUrl,
          'email': currentUser.email,
        }, SetOptions(merge: true));
        await currentUser.updateDisplayName(_nameController.text);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Profile updated successfully!")));
        _loadUserProfile();  // Reload the user data after updating
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Failed to update profile: $e")));
    }
  }

  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 50),
            GestureDetector(
              onTap: _pickImage,
              child: CircleAvatar(
                radius: 50,
                backgroundImage: _profileImageUrl.isEmpty
                    ? AssetImage('assets/default_avatar.png') // Default placeholder image
                    : (_profileImageUrl.startsWith('http')
                    ? NetworkImage(_profileImageUrl) as ImageProvider
                    : FileImage(File(_profileImageUrl))), // Handle local file
              ),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: _pickImage,
              child: Text("Edit Profile Photo", style: TextStyle(color: Colors.grey[700])),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                hintText: "Full Name",
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _phoneController,
              decoration: InputDecoration(
                hintText: "Phone Number",
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _updateProfile,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                minimumSize: Size(double.infinity, 50),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: Text("Save Changes", style: TextStyle(fontSize: 16, color: Colors.white)),
            ),
            const SizedBox(height: 20),
            TextButton(
              onPressed: _logout,
              child: Text("Logout", style: TextStyle(color: Colors.black, fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}
