import 'package:flutter/material.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'group_details_page.dart';

class ViewGroupsPage extends StatefulWidget {
  @override
  _ViewGroupsPageState createState() => _ViewGroupsPageState();
}

class _ViewGroupsPageState extends State<ViewGroupsPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  List<Map<String, dynamic>> _groups = [];

  @override
  void initState() {
    super.initState();
    _fetchGroups();
  }

  Future<void> _fetchGroups() async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('groups')
          .get();

      final groups = snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        return {
          'id': doc.id,
          'name': data['name'],
          'members': data['members'], // List of members
        };
      }).toList();

      setState(() {
        _groups = groups;
      });
    } catch (e) {
      print("Error fetching groups: $e");
    }
  }

  Future<bool> _checkContactsPermission() async {
    final status = await Permission.contacts.status;

    if (status.isDenied) {
      final permissionStatus = await Permission.contacts.request();
      return permissionStatus.isGranted;
    } else if (status.isPermanentlyDenied) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
              "Contacts permission is permanently denied. Please enable it in settings."),
          action: SnackBarAction(
            label: "Settings",
            onPressed: () {
              openAppSettings();
            },
          ),
        ),
      );
      return false;
    }
    return status.isGranted;
  }

  Future<Iterable<Contact>> _fetchContacts() async {
    try {
      final contacts = await ContactsService.getContacts(withThumbnails: false);
      return contacts;
    } catch (e) {
      print("Error fetching contacts: $e");
      return [];
    }
  }

  Future<void> _editGroupMembers(String groupId, List<String> currentMembers) async {
    final hasPermission = await _checkContactsPermission();
    if (!hasPermission) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Contacts permission is required to edit group members.")),
      );
      return;
    }

    final contacts = await _fetchContacts();
    if (contacts.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("No contacts available to add.")),
      );
      return;
    }

    final List<String> selectedMembers = await showDialog<List<String>>(
      context: context,
      builder: (context) {
        return _ContactSelectionDialog(
          contacts: contacts.toList(),
          selectedMembers: currentMembers,
        );
      },
    ) ??
        [];

    if (selectedMembers.isNotEmpty) {
      try {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(_auth.currentUser!.uid)
            .collection('groups')
            .doc(groupId)
            .update({'members': selectedMembers});

        _fetchGroups();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Group members updated successfully.")),
        );
      } catch (e) {
        print("Error updating group members: $e");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error updating group members: $e")),
        );
      }
    }
  }

  Widget _buildGroupList() {
    return ListView.builder(
      itemCount: _groups.length,
      itemBuilder: (context, index) {
        final group = _groups[index];
        final groupName = group['name'];
        final members = group['members'];
        final groupId = group['id'];

        return Card(
          child: ListTile(
            title: Text(groupName),
            subtitle: Text("Members: ${members.join(', ')}"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => GroupDetailsPage(groupId: groupId),
                ),
              );
            },
            trailing: PopupMenuButton<String>(
              icon: Icon(Icons.more_vert),
              itemBuilder: (context) {
                return [
                  PopupMenuItem<String>(
                    value: 'edit',
                    child: Text('Edit Members'),
                  ),
                  PopupMenuItem<String>(
                    value: 'delete',
                    child: Text('Delete Group'),
                  ),
                ];
              },
              onSelected: (value) async {
                if (value == 'edit') {
                  _editGroupMembers(groupId, members);
                } else if (value == 'delete') {
                  final confirmDelete = await _showDeleteConfirmationDialog();
                  if (confirmDelete) {
                    _deleteGroup(groupId);
                  }
                }
              },
            ),
          ),
        );
      },
    );
  }

  Future<bool> _showDeleteConfirmationDialog() async {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: const Text("Delete Group"),
          content: const Text("Are you sure you want to delete this group?"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text("Confirm"),
            ),
          ],
        );
      },
    ).then((value) => value ?? false);
  }

  Future<void> _deleteGroup(String groupId) async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('groups')
          .doc(groupId)
          .delete();

      _fetchGroups();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Group deleted successfully.")),
      );
    } catch (e) {
      print("Error deleting group: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error deleting group: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('View Groups'),
        backgroundColor: Colors.blue, // Set the app bar color to blue
      ),

      body: _groups.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : _buildGroupList(),

    );
  }
}

class _ContactSelectionDialog extends StatefulWidget {
  final List<Contact> contacts;
  final List<String> selectedMembers;

  const _ContactSelectionDialog({required this.contacts, required this.selectedMembers, Key? key})
      : super(key: key);

  @override
  __ContactSelectionDialogState createState() => __ContactSelectionDialogState();
}

class __ContactSelectionDialogState extends State<_ContactSelectionDialog> {
  late List<String> _selectedContacts;
  TextEditingController _searchController = TextEditingController();
  List<Contact> _filteredContacts = [];

  @override
  void initState() {
    super.initState();
    _selectedContacts = List.from(widget.selectedMembers);
    _filteredContacts = widget.contacts;
    _searchController.addListener(_filterContacts);
  }

  void _filterContacts() {
    String query = _searchController.text.toLowerCase();
    setState(() {
      _filteredContacts = widget.contacts.where((contact) {
        return contact.displayName != null &&
            contact.displayName!.toLowerCase().contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text("Select Members"),
      content: SingleChildScrollView(
        child: Column(
          children: [
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: "Search Contacts",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 10),
            Column(
              children: _filteredContacts.map((contact) {
                return CheckboxListTile(
                  title: Text(contact.displayName ?? "Unknown"),
                  value: _selectedContacts.contains(contact.displayName),
                  onChanged: (bool? selected) {
                    setState(() {
                      if (selected != null) {
                        if (selected) {
                          _selectedContacts.add(contact.displayName ?? "Unknown");
                        } else {
                          _selectedContacts.remove(contact.displayName ?? "Unknown");
                        }
                      }
                    });
                  },
                );
              }).toList(),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, []),
          child: const Text("Cancel"),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context, _selectedContacts),
          child: const Text("Save"),
        ),
      ],
    );
  }
}