import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';


class EditExpensePage extends StatefulWidget {
  final Map<String, dynamic> expense;

  const EditExpensePage({required this.expense, Key? key}) : super(key: key);

  @override
  _EditExpensePageState createState() => _EditExpensePageState();
}

class _EditExpensePageState extends State<EditExpensePage> {
  late TextEditingController _titleController;
  late TextEditingController _amountController;
  late TextEditingController _descriptionController;

  File? _newBillImage; // To store the new selected bill image
  final ImagePicker _picker = ImagePicker();
  bool _isUploading = false;

  DateTime? _selectedExpenseDate;
  DateTime? _selectedRenewalDate; // For subscription renewal date
  String? _selectedCategory;

  final List<String> _categories = [
    'Utilities',
    'Food',
    'Transport',
    'Entertainment',
    'Subscriptions',
    'Shopping',
    'Other',
  ];

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.expense['title']);
    _amountController = TextEditingController(text: widget.expense['amount'].toString());
    _descriptionController = TextEditingController(text: widget.expense['description']);

    _selectedExpenseDate = widget.expense['expenseDate'];
    _selectedRenewalDate = widget.expense['renewalDate'] != null
        ? DateTime.tryParse(widget.expense['renewalDate'])
        : null;
    _selectedCategory = widget.expense['category'];
  }

  Future<void> _pickImage() async {
    final pickedImage = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      setState(() {
        _newBillImage = File(pickedImage.path);
      });
    }
  }

  Future<void> _selectDate(BuildContext context, bool isExpenseDate) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isExpenseDate
          ? (_selectedExpenseDate ?? DateTime.now())
          : (_selectedRenewalDate ?? DateTime.now()),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        if (isExpenseDate) {
          _selectedExpenseDate = picked;
        } else {
          _selectedRenewalDate = picked;
        }
      });
    }
  }

  Future<void> _updateExpense() async {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) return;

    setState(() {
      _isUploading = true;
    });

    String? updatedBillUrl = widget.expense['billUrl']; // Keep existing bill URL if no new image

    try {
      // Upload new bill image to Firebase Storage if a new image is selected
      if (_newBillImage != null) {
        final storageRef = FirebaseStorage.instance
            .ref()
            .child('bills/${user.uid}/${DateTime.now().millisecondsSinceEpoch}.jpg');
        final uploadTask = storageRef.putFile(_newBillImage!);
        final snapshot = await uploadTask;
        updatedBillUrl = await snapshot.ref.getDownloadURL();
      }

      // Update expense details in Firestore
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('expenses')
          .doc(widget.expense['id'])
          .update({
        'title': _titleController.text.trim(),
        'amount': double.parse(_amountController.text.trim()),
        'description': _descriptionController.text.trim(),
        'billUrl': updatedBillUrl, // Update the bill URL
        'expenseDate': _selectedExpenseDate,
        'category': _selectedCategory,
        if (_selectedCategory == 'Subscriptions' && _selectedRenewalDate != null)
          'renewalDate': _selectedRenewalDate?.toIso8601String(),
      });

      Navigator.pop(context); // Go back after successful update
    } catch (e) {
      print('Error updating expense: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error updating expense: $e')),
      );
    } finally {
      setState(() {
        _isUploading = false;
      });
    }
  }

  Future<void> _deleteExpense() async {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null) return;

    try {
      // Delete expense from Firestore
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('expenses')
          .doc(widget.expense['id'])
          .delete();

      // Optionally, delete the associated bill image from Firebase Storage
      if (widget.expense['billUrl'] != null) {
        final storageRef = FirebaseStorage.instance.refFromURL(widget.expense['billUrl']);
        await storageRef.delete();
      }

      Navigator.pop(context); // Go back after deletion
    } catch (e) {
      print('Error deleting expense: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error deleting expense: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Expense'),
        backgroundColor: Colors.blue, // Set the app bar color to blue
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: _deleteExpense,
          ),
        ],
      ),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _amountController,
                decoration: const InputDecoration(labelText: 'Amount'),
                keyboardType: TextInputType.numberWithOptions(decimal: true),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _descriptionController,
                decoration: const InputDecoration(labelText: 'Description'),
                maxLines: null, // Allows unlimited lines
                keyboardType: TextInputType.multiline, // Allows multiline input
                textInputAction: TextInputAction.newline, // Makes the 'Enter' key add a new line
              )

              ,

              // Category Dropdown
              DropdownButtonFormField<String>(
                value: _selectedCategory,
                decoration: const InputDecoration(labelText: 'Category'),
                items: _categories.map((category) {
                  return DropdownMenuItem(
                    value: category,
                    child: Text(category),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedCategory = value;
                  });
                },
              ),
              const SizedBox(height: 16),

              // Expense Date Picker
              GestureDetector(
                onTap: () => _selectDate(context, true),
                child: AbsorbPointer(
                  child: TextFormField(
                    decoration: InputDecoration(
                      labelText: 'Expense Date',
                      hintText: _selectedExpenseDate != null
                          ? DateFormat('yyyy-MM-dd').format(_selectedExpenseDate!)
                          : 'Select Expense Date',
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Renewal Date Picker (Only for Subscriptions)
              if (_selectedCategory == 'Subscriptions')
                GestureDetector(
                  onTap: () => _selectDate(context, false),
                  child: AbsorbPointer(
                    child: TextFormField(
                      decoration: InputDecoration(
                        labelText: 'Renewal Date',
                        hintText: _selectedRenewalDate != null
                            ? DateFormat('yyyy-MM-dd').format(_selectedRenewalDate!)
                            : 'Select Renewal Date',
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 24),

              if (widget.expense['billUrl'] != null && _newBillImage == null)
                Column(
                  children: [
                    const Text('Current Bill:'),
                    Image.network(
                      widget.expense['billUrl'],
                      height: 200,
                      fit: BoxFit.cover,
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              if (_newBillImage != null)
                Column(
                  children: [
                    const Text('New Bill Image:'),
                    Image.file(
                      _newBillImage!,
                      height: 200,
                      fit: BoxFit.cover,
                    ),
                    const SizedBox(height: 16),
                  ],
                ),
              ElevatedButton.icon(
                icon: const Icon(Icons.upload_file),
                label: const Text('Upload New Bill Image'),
                onPressed: _pickImage,
              ),
              const SizedBox(height: 24),
              _isUploading
                  ? const Center(child: CircularProgressIndicator())
                  : ElevatedButton(
                onPressed: _updateExpense,
                child: const Text('Update Expense'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
