import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class GroupDetailsPage extends StatefulWidget {
  final String groupId; // Group ID passed from the previous page

  const GroupDetailsPage({required this.groupId, Key? key}) : super(key: key);

  @override
  _GroupDetailsPageState createState() => _GroupDetailsPageState();
}

class _GroupDetailsPageState extends State<GroupDetailsPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  List<String> _members = [];
  double _totalExpenses = 0.0;
  Map<String, double> _balances = {}; // Track individual balances
  final TextEditingController _expenseController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchGroupDetails();
  }

  // Fetch group details and balances from Firestore
  Future<void> _fetchGroupDetails() async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      // Fetch group data using the groupId
      final groupDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('groups')
          .doc(widget.groupId)
          .get();

      final groupData = groupDoc.data() as Map<String, dynamic>;

      setState(() {
        _members = List<String>.from(groupData['members'] ?? []);
        _totalExpenses = groupData['totalExpenses']?.toDouble() ?? 0.0;
        _balances = Map<String, double>.from(groupData['balances'] ?? {});
      });
    } catch (e) {
      print("Error fetching group details: $e");
    }
  }

  // Add expense to Firestore
  Future<void> _addExpense(double amount) async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      final shareAmount = amount / _members.length;

      // Update balances locally
      for (var member in _members) {
        _balances[member] = (_balances[member] ?? 0.0) - shareAmount;
      }

      // Update Firestore
      final groupRef = FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('groups')
          .doc(widget.groupId);

      await groupRef.update({
        'totalExpenses': FieldValue.increment(amount),
        'balances': _balances,
      });

      // Add expense details to Firestore
      await groupRef.collection('expenses').add({
        'amount': amount,
        'createdAt': Timestamp.now(),
        'splitAmount': shareAmount,
        'members': _members,
      });

      // Update local state
      setState(() {
        _totalExpenses += amount;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Expense of ₹${amount.toStringAsFixed(2)} added and split equally.")),
      );
    } catch (e) {
      print("Error adding expense: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error adding expense: $e")),
      );
    }
  }

  // Mark a member's balance as paid
  Future<void> _markAsPaid(String member) async {
    final user = _auth.currentUser;
    if (user == null) return;

    final memberBalance = _balances[member] ?? 0.0;

    try {
      // Update balances locally
      setState(() {
        _totalExpenses += memberBalance;
        _balances[member] = 0.0; // Set balance to zero
      });

      // Update Firestore
      final groupRef = FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('groups')
          .doc(widget.groupId);

      await groupRef.update({
        'totalExpenses': _totalExpenses,
        'balances': _balances,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("$member's balance marked as paid.")),
      );
    } catch (e) {
      print("Error marking as paid: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error marking as paid: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Group Details'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Total Expenses: ₹${_totalExpenses.toStringAsFixed(2)}",
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Text(
              "Member Balances",
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: _members.length,
                itemBuilder: (context, index) {
                  final member = _members[index];
                  final balance = _balances[member] ?? 0.0;

                  return ListTile(
                    title: Text(member),
                    subtitle: Text("Balance: ₹${balance.toStringAsFixed(2)}"),
                    trailing: balance == 0
                        ? const Icon(Icons.check_circle, color: Colors.green)
                        : IconButton(
                      icon: const Icon(Icons.warning, color: Colors.red),
                      onPressed: () {
                        _markAsPaid(member); // Mark as paid
                      },
                    ),
                  );
                },
              ),
            ),
            const Divider(),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _expenseController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: "Enter Expense Amount",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () async {
                    if (_expenseController.text.isNotEmpty) {
                      final double amount = double.parse(_expenseController.text.trim());
                      await _addExpense(amount);
                      _expenseController.clear();
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Please enter a valid amount.")),
                      );
                    }
                  },
                  child: const Text("Add"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
