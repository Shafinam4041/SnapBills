import 'package:flutter/material.dart';
import 'package:contacts_service/contacts_service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'viewgroups.dart'; // Import the ViewGroupsPage

class AddGroupPage extends StatefulWidget {
  @override
  _AddGroupPageState createState() => _AddGroupPageState();
}

class _AddGroupPageState extends State<AddGroupPage> {
  List<Contact> _contacts = [];
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final TextEditingController _groupNameController = TextEditingController();
  List<String> _selectedContacts = [];

  @override
  void initState() {
    super.initState();
    _fetchContacts();
  }

  // Fetch contacts from the phone's contact list
  Future<void> _fetchContacts() async {
    try {
      final Iterable<Contact> contacts = await ContactsService.getContacts();
      setState(() {
        _contacts = contacts.toList();
      });
    } catch (e) {
      print("Error fetching contacts: $e");
    }
  }

  // Create a new group and add selected contacts to Firestore
  Future<void> _createGroup() async {
    final user = _auth.currentUser;
    if (user == null) return;

    final groupName = _groupNameController.text.trim();
    if (groupName.isEmpty || _selectedContacts.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please provide a group name and select contacts.")),
      );
      return;
    }

    try {
      // Add group to Firestore
      DocumentReference groupRef = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('groups')
          .add({
        'name': groupName,
        'createdAt': Timestamp.now(),
        'members': _selectedContacts, // Store selected contacts' identifiers
        'owner': user.uid, // Owner of the group
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Group '$groupName' created successfully")),
      );

      // Clear form after creating group
      setState(() {
        _groupNameController.clear();
        _selectedContacts.clear();
      });

      // Navigate to ViewGroupsPage
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ViewGroupsPage(), // Navigate to the ViewGroupsPage
        ),
      );

    } catch (e) {
      print("Error creating group: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error creating group: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Group'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _groupNameController,
              decoration: const InputDecoration(labelText: 'Group Name'),
            ),
            const SizedBox(height: 16),
            const Text("Select Contacts to Add to Group"),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: _contacts.length,
                itemBuilder: (context, index) {
                  final contact = _contacts[index];
                  return CheckboxListTile(
                    title: Text(contact.displayName ?? "Unknown"),
                    value: _selectedContacts.contains(contact.displayName),
                    onChanged: (bool? selected) {
                      setState(() {
                        if (selected != null && selected) {
                          _selectedContacts.add(contact.displayName ?? "Unknown");
                        } else {
                          _selectedContacts.remove(contact.displayName ?? "Unknown");
                        }
                      });
                    },
                  );
                },
              ),
            ),
            ElevatedButton(
              onPressed: _createGroup,
              child: const Text("Create Group"),
            ),
          ],
        ),
      ),
    );
  }
}