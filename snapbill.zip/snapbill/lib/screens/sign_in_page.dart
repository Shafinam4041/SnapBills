import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'auth_service.dart';

class SignInPage extends StatelessWidget {
  final AuthService _authService = AuthService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Snapbill - Sign In"),
      ),
      body: StreamBuilder<User?>(
        stream: _authService.userChanges,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            final user = snapshot.data!;
            return LoggedInPage(user: user);
          } else {
            return Center(
              child: ElevatedButton.icon(
                icon: Icon(Icons.login),
                label: Text("Sign In with Google"),
                onPressed: () async {
                  final user = await _authService.signInWithGoogle();
                  if (user != null) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text("Welcome ${user.displayName}!"),
                    ));
                  }
                },
              ),
            );
          }
        },
      ),
    );
  }
}

class LoggedInPage extends StatelessWidget {
  final User user;

  LoggedInPage({required this.user});

  @override
  Widget build(BuildContext context) {
    final AuthService _authService = AuthService();

    return Scaffold(
      appBar: AppBar(
        title: Text("Welcome ${user.displayName}"),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () async {
              await _authService.signOut();
            },
          ),
        ],
      ),
      body: Center(
        child: Text(
          "Hello ${user.displayName},\nYour email: ${user.email}",
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
