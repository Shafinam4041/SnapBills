import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:snapbill/screens/expense_page.dart';
import 'package:snapbill/screens/scanbill.dart';
import 'package:snapbill/screens/view_expenses_page.dart';
import 'package:snapbill/screens/trendspage.dart';
import 'package:snapbill/screens/borrow.dart';
import 'package:snapbill/screens/bills.dart';
import 'package:snapbill/screens/card.dart';
import 'package:snapbill/screens/profile.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({Key? key}) : super(key: key);

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    ViewExpensesPage(),
    ExpensePage(),
    ProfilePage(user: FirebaseAuth.instance.currentUser!), // Moved Profile page to 3rd index
  ];

  void _onItemTapped(int index) {
    if (index == 3) {
      _showOthersBottomSheet(context);
    } else {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex], // Directly show selected page without extra padding
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  /// Custom attractive BottomNavigationBar
  Widget _buildBottomNavigationBar() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue.shade700, Colors.blue.shade900], // Gradient background
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(25),
          topRight: Radius.circular(25),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3), // Shadow effect
            spreadRadius: 5,
            blurRadius: 10,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(25),
          topRight: Radius.circular(25),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: Colors.white, // Selected item color
          unselectedItemColor: Colors.white70, // Unselected item color
          selectedFontSize: 14,
          unselectedFontSize: 12,
          currentIndex: _selectedIndex,
          onTap: _onItemTapped,
          type: BottomNavigationBarType.fixed,
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home, size: 28),
              label: "Dashboard",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.account_balance_wallet, size: 28),
              label: "Add Expense",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person, size: 28),
              label: "Profile",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.more_horiz, size: 28),
              label: "Others",
            ),
          ],
        ),
      ),
    );
  }

  /// **Bottom Sheet for 'Others' Section**
  void _showOthersBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.trending_up, color: Colors.blue),
                title: const Text("Trends"),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => TrendsPage())),
              ),
              ListTile(
                leading: const Icon(Icons.monetization_on, color: Colors.green),
                title: const Text("Debts"),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => ManageDebtsPage())),
              ),
              ListTile(
                leading: const Icon(Icons.receipt_long, color: Colors.orange),
                title: const Text("Bills"),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => BillScannerApp())),
              ),
              ListTile(
                leading: const Icon(Icons.qr_code, color: Colors.purple),
                title: const Text("UPI Payments"),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => ScanQRCodePage())),
              ),
              ListTile(
                leading: const Icon(Icons.credit_card, color: Colors.red),
                title: const Text("Cards"),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context) => CardDetailsPage())),
              ),
            ],
          ),
        );
      },
    );
  }
}
