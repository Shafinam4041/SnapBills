import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'debt_history_page.dart'; // Import DebtHistoryPage

class DebtorsListPage extends StatefulWidget {
  @override
  _DebtorsListPageState createState() => _DebtorsListPageState();
}

class _DebtorsListPageState extends State<DebtorsListPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  List<Map<String, dynamic>> _debtors = [];
  List<Map<String, dynamic>> _creditors = [];
  double _totalDebts = 0.0;
  double _totalCredits = 0.0;
  int _selectedIndex = 0; // 0 for Debtors, 1 for Creditors

  @override
  void initState() {
    super.initState();
    _fetchDebtorsAndCreditors();
  }

  Future<void> _fetchDebtorsAndCreditors() async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('debts')
          .get();

      Map<String, double> debtorsMap = {};
      Map<String, double> creditorsMap = {};
      double totalDebts = 0.0;
      double totalCredits = 0.0;

      for (var doc in snapshot.docs) {
        final data = doc.data();
        String contactName = data['contactName'];
        double amount = data['amount'];

        if (data['type'] == 'You Got') {
          debtorsMap[contactName] = (debtorsMap[contactName] ?? 0) + amount;
          totalDebts += amount;
        } else if (data['type'] == 'You Gave') {
          creditorsMap[contactName] = (creditorsMap[contactName] ?? 0) + amount;
          totalCredits += amount;
        }
      }

      setState(() {
        _debtors = debtorsMap.entries.map((e) => {'name': e.key, 'amount': e.value}).toList();
        _creditors = creditorsMap.entries.map((e) => {'name': e.key, 'amount': e.value}).toList();
        _totalDebts = totalDebts;
        _totalCredits = totalCredits;
      });
    } catch (e) {
      print("Error fetching debtors and creditors: $e");
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_selectedIndex == 0 ? "Debtors" : "Creditors"),
        backgroundColor: Colors.blue, // Blue app bar
      ),
      body: _buildListView(),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.monetization_on),
            label: 'Debtors',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.money_off),
            label: 'Creditors',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        onTap: _onItemTapped,
      ),
    );
  }


  Widget _buildListView() {
    List<Map<String, dynamic>> list = _selectedIndex == 0 ? _debtors : _creditors;
    Color titleColor = _selectedIndex == 0 ? Colors.green : Colors.red;
    double totalAmount = _selectedIndex == 0 ? _totalDebts : _totalCredits;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Removed the heading "Debtors" or "Creditors"
              Text(
                "Total Amount: ₹${totalAmount.toStringAsFixed(2)}",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: titleColor),
              ),
            ],
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? Center(child: Text("No records found"))
              : ListView.builder(
            itemCount: list.length,
            itemBuilder: (context, index) {
              final item = list[index];
              return ListTile(
                title: Text(item['name']),
                subtitle: Text("₹${item['amount'].toStringAsFixed(2)}"),
                trailing: Icon(Icons.arrow_forward_ios),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DebtHistoryPage(contactName: item['name']),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}
