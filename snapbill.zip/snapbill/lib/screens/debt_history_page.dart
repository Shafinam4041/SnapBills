import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart'; // Import DateFormat from intl package
import 'package:share_plus/share_plus.dart';

class DebtHistoryPage extends StatefulWidget {
  final String contactName; // Contact name passed from the previous page

  const DebtHistoryPage({required this.contactName, Key? key}) : super(key: key);

  @override
  _DebtHistoryPageState createState() => _DebtHistoryPageState();
}

class _DebtHistoryPageState extends State<DebtHistoryPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  List<Map<String, dynamic>> _debts = [];
  double _youGaveTotal = 0.0;
  double _youGotTotal = 0.0;
  String _grandTotalType = ""; // To store either "You Gave" or "You Got"
  double _grandTotal = 0.0; // To store the final total
  DateTime _selectedDate = DateTime.now(); // Track the selected date

  @override
  void initState() {
    super.initState();
    _fetchDebts();
  }

  // Fetch debts related to the selected contact from Firestore
  Future<void> _fetchDebts() async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('debts')
          .where('contactName', isEqualTo: widget.contactName)
          .get();

      double youGaveTotal = 0.0;
      double youGotTotal = 0.0;

      final debts = snapshot.docs.map((doc) {
        final data = doc.data() as Map<String, dynamic>;
        if (data['type'] == 'You Gave') {
          youGaveTotal += data['amount'];
        } else if (data['type'] == 'You Got') {
          youGotTotal += data['amount'];
        }
        return {
          'id': doc.id,
          'amount': data['amount'],
          'type': data['type'],
          'createdAt': data['createdAt'],
          'date': data['date'],
          'description': data['description'],
        };
      }).toList();

      // Determine the grand total and which category (You Gave or You Got) is more
      double finalTotal = youGaveTotal - youGotTotal;
      if (finalTotal > 0) {
        setState(() {
          _grandTotal = finalTotal;
          _grandTotalType = "You Gave";
        });
      } else if (finalTotal < 0) {
        setState(() {
          _grandTotal = -finalTotal; // Make it positive
          _grandTotalType = "You Got";
        });
      } else {
        setState(() {
          _grandTotal = 0.0;
          _grandTotalType = "No Balance";
        });
      }

      setState(() {
        _debts = debts;
        _youGaveTotal = youGaveTotal;
        _youGotTotal = youGotTotal;
      });
    } catch (e) {
      print("Error fetching debts: $e");
    }
  }

  // Function to add a new debt to Firestore
  Future<void> _addDebt(String contactName, double amount, String type, DateTime date, String description) async {
    final user = _auth.currentUser;
    if (user == null) return;

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('debts')
          .add({
        'contactName': contactName,
        'amount': amount,
        'type': type, // "You Gave" or "You Got"
        'date': date,
        'description': description,
        'createdAt': Timestamp.now(),
      });

      // Refresh the debts list after adding the new debt
      _fetchDebts();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$type amount added for $contactName')),
      );
    } catch (e) {
      print("Error adding debt: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error adding debt: $e")),
      );
    }
  }

  // Show a dialog to input the amount, date, description, and type of the debt (You Gave or You Got)
  Future<void> _addDebtDialog(String type) async {
    final TextEditingController _amountController = TextEditingController();
    final TextEditingController _descriptionController = TextEditingController();

    // Date picker for selecting a date
    Future<void> _selectDate() async {
      final DateTime? pickedDate = await showDatePicker(
        context: context,
        initialDate: _selectedDate,
        firstDate: DateTime(2000),
        lastDate: DateTime(2100),
      );
      if (pickedDate != null && pickedDate != _selectedDate) {
        setState(() {
          _selectedDate = pickedDate;
        });
      }
    }

    return showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Add Debt for ${widget.contactName}"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Date picker button
              GestureDetector(
                onTap: _selectDate,
                child: AbsorbPointer(
                  child: TextField(
                    decoration: InputDecoration(
                      labelText: 'Date',
                      hintText: "${_selectedDate.toLocal()}".split(' ')[0],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              // Amount input field
              TextField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(labelText: "Amount"),
              ),
              const SizedBox(height: 16),
              // Description input field
              TextField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: "Description"),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () {
                if (_amountController.text.isNotEmpty) {
                  final double amount = double.parse(_amountController.text.trim());
                  final description = _descriptionController.text.trim();
                  _addDebt(widget.contactName, amount, type, _selectedDate, description);
                  Navigator.pop(context);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text("Please enter a valid amount.")),
                  );
                }
              },
              child: Text("Save"),
            ),
          ],
        );
      },
    );
  }

  // Function to share the debt information via WhatsApp or other apps
  void _shareDebtInfo() {
    String debtInfo = "Debt with ${widget.contactName}:\n";
    for (var debt in _debts) {
      String formattedDate = DateFormat('dd/MM/yyyy').format(debt['date'].toDate());
      debtInfo += "\n${debt['type']} - ₹${debt['amount'].toStringAsFixed(2)}\n"
          "Date: $formattedDate\nDescription: ${debt['description']}\n";
    }

    // Share using the share_plus package
    Share.share(debtInfo);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.contactName} - Debt History'),
        backgroundColor: Colors.blue,
        actions: [
          IconButton(
            icon: Icon(Icons.share),
            onPressed: _shareDebtInfo, // Call the share function when tapped
            tooltip: "Share Debt Info",
          ),
        ],
      ),
      body: _debts.isEmpty
          ? const Center(child: Text('No debts found.'))
          : Column(
        children: [
          ListTile(
            title: Text('Grand Total'),
            trailing: Text('$_grandTotalType: ₹${_grandTotal.toStringAsFixed(2)}'),
          ),
          const Divider(),
          Expanded(
            child: ListView.builder(
              itemCount: _debts.length,
              itemBuilder: (context, index) {
                final debt = _debts[index];
                String formattedDate = DateFormat('dd/MM/yyyy').format(debt['date'].toDate());

                return ListTile(
                  title: Text(debt['type']),
                  subtitle: Text('₹${debt['amount'].toStringAsFixed(2)}\n${debt['description']}'),
                  trailing: Text(
                    formattedDate,
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton(
              onPressed: () => _addDebtDialog('You Gave'),
              child: const Text('You Gave'),
            ),
            ElevatedButton(
              onPressed: () => _addDebtDialog('You Got'),
              child: const Text('You Got'),
            ),
          ],
        ),
      ),
    );
  }
}
